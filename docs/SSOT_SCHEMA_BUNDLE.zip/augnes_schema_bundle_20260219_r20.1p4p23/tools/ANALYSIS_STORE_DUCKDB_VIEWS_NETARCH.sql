-- ANALYSIS_STORE_DUCKDB_VIEWS_NETARCH.sql
-- Purpose: Reference DuckDB views for NetArch-G aggregation into WL_netarch_* covariates
-- Assumes a table (or view) named `events_flat` exists with at least:
--   event_id, event_type, episode_id, trace_id, observed_time, recorded_time, event_time, event_time_status, payload_json
-- where payload_json is the raw payload as a JSON string.
--
-- Notes:
-- Compatibility note:
--   * MODE_SWITCH is the NetArch-G "control_mode_id" transition event (fine-grained control regime).
--   * BEHAVIOR_STATE_SWITCH (if present) is a separate coarse behavior/regime milestone. Do NOT treat it as MODE_SWITCH.
--   Keep them semantically distinct in downstream analysis.
--
-- - Analysis-only. Derived scores must NOT be used to promote Evidence/Claim.
-- - This file is a reference implementation. Adjust extract keys to match your payloads.

-- ----------------------------------------------------------------------
-- 1) Base extraction: NetArch events
-- ----------------------------------------------------------------------

create or replace view v_netarch_events as
select
  event_id,
  event_type,
  episode_id,
  trace_id,
  observed_time,
  recorded_time,
  event_time,
  event_time_status,
  json_extract(payload_json, '$') as payload
from events_flat
where event_type in ('MODE_SWITCH', 'BRIDGE_CALL', 'GRAPH_MAINTENANCE');

-- ----------------------------------------------------------------------
-- 2) Extract a few fields (string/number) for aggregation
-- ----------------------------------------------------------------------

create or replace view v_netarch_events_extracted as
select
  event_id,
  event_type,
  episode_id,
  trace_id,
  observed_time,
  recorded_time,
  event_time,
  event_time_status,
  cast(json_extract_string(payload_json, '$.from_mode') as varchar) as from_mode,
  cast(json_extract_string(payload_json, '$.to_mode') as varchar) as to_mode,
  cast(json_extract_string(payload_json, '$.trigger') as varchar) as trigger,
  cast(json_extract_string(payload_json, '$.result') as varchar) as bridge_result,
  cast(json_extract(payload_json, '$.utility_delta') as double) as utility_delta
from events_flat
where event_type in ('MODE_SWITCH', 'BRIDGE_CALL', 'GRAPH_MAINTENANCE');

-- ----------------------------------------------------------------------
-- 3) Episode-level covariates (WL_netarch_*)
-- ----------------------------------------------------------------------

create or replace view v_episode_netarch_covariates as
select
  episode_id,
  count_if(event_type = 'MODE_SWITCH') as WL_netarch_mode_switch_count,
  count_if(event_type = 'MODE_SWITCH') as WL_netarch_control_mode_switch_count,
  count_if(event_type = 'BRIDGE_CALL') as WL_netarch_bridge_calls,
  case
    when count_if(event_type = 'BRIDGE_CALL') = 0 then null
    else (count_if(event_type = 'BRIDGE_CALL' and bridge_result = 'hit')::double
          / count_if(event_type = 'BRIDGE_CALL')::double)
  end as WL_netarch_bridge_hit_rate,
  count_if(event_type = 'GRAPH_MAINTENANCE') as WL_netarch_maintenance_runs,
  avg(case when event_type='BRIDGE_CALL' then utility_delta else null end) as WL_netarch_bridge_utility_mean
from v_netarch_events_extracted
group by episode_id;

-- ----------------------------------------------------------------------
-- 4) Enrich SCORE_REPORT (optional)
-- ----------------------------------------------------------------------

create or replace view v_score_report_netarch_enriched as
select
  sr.*,
  nc.WL_netarch_mode_switch_count,
  nc.WL_netarch_control_mode_switch_count,
  nc.WL_netarch_bridge_calls,
  nc.WL_netarch_bridge_hit_rate,
  nc.WL_netarch_maintenance_runs,
  nc.WL_netarch_bridge_utility_mean
from v_score_report sr
left join v_episode_netarch_covariates nc
  on sr.episode_id = nc.episode_id;


-- ----------------------------------------------------------------------
-- 5) Optional: Normalize legacy VAR key alias (ri_selfgraph vs RI_selfgraph)
-- ----------------------------------------------------------------------
-- If you store STATE_SNAPSHOT as an event_type with JSON payload in events_flat,
-- this view provides a normalized ri_selfgraph_norm using COALESCE across both key spellings.
-- Adapt the JSON paths if your payload layout differs.

create or replace view v_state_snapshot_var_norm as
select
  episode_id,
  trace_id,
  observed_time,
  recorded_time,
  -- preferred modern key, with legacy fallback
  coalesce(
    try_cast(json_extract_string(payload_json, '$.metrics_optional.var.ri_selfgraph') as double),
    try_cast(json_extract_string(payload_json, '$.metrics_optional.var.RI_selfgraph') as double)
  ) as ri_selfgraph_norm,
  try_cast(json_extract_string(payload_json, '$.metrics_optional.var.var_hat') as double) as var_hat,
  try_cast(json_extract_string(payload_json, '$.metrics_optional.var.sa_rank_hat') as double) as sa_rank_hat,
  json_extract_string(payload_json, '$.metrics_optional.var.var_profile') as var_profile
from events_flat
where event_type = 'STATE_SNAPSHOT';
