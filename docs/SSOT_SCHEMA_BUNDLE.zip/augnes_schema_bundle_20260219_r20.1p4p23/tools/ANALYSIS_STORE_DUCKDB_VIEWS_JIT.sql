-- ANALYSIS_STORE_DUCKDB_VIEWS_JIT.sql
-- Purpose: Reference DuckDB views for JIT_CONSTRUAL_* aggregation into WL_jit_* covariates
-- Assumes a table (or view) named `events_flat` exists with at least:
--   event_id, event_type, episode_id, trace_id, observed_time, recorded_time, event_time, event_time_status, payload_json
-- where payload_json is the raw payload as a JSON string.
--
-- Notes:
-- - This is analysis-only. It does NOT create authority. Do not use derived scores to promote Evidence/Claim.
-- - active_set_n_t reconstruction uses: seed_n + cumsum(added_n) - cumsum(removed_n)

-- ----------------------------------------------------------------------
-- 1) Base extraction: JIT events
-- ----------------------------------------------------------------------

create or replace view v_jit_events as
select
  event_id,
  event_type,
  episode_id,
  trace_id,
  observed_time,
  recorded_time,
  -- core keys
  json_extract_string(payload_json, '$.jit_cycle_id') as jit_cycle_id,
  json_extract_string(payload_json, '$.step_id') as jit_step_id,

  -- counts (nullable unless the event kind matches)
  case when event_type = 'JIT_CONSTRUAL_INIT'
    then json_array_length(json_extract(payload_json, '$.seed_obj_ids'))
  end as seed_n,

  case when event_type = 'JIT_CONSTRUAL_LOOKAHEAD'
    then json_array_length(json_extract(payload_json, '$.needs'))
  end as needs_n,

  case when event_type = 'JIT_CONSTRUAL_ENCODE'
    then json_array_length(json_extract(payload_json, '$.added_obj_ids'))
  end as added_n,

  case when event_type = 'JIT_CONSTRUAL_PRUNE'
    then json_array_length(json_extract(payload_json, '$.removed_obj_ids'))
  end as removed_n,

  -- SIM meta
  case when event_type = 'JIT_CONSTRUAL_SIM'
    then json_extract_string(payload_json, '$.sim_level')
  end as sim_level,

  case
    when json_extract_string(payload_json, '$.sim_level') = 'L0' then 0
    when json_extract_string(payload_json, '$.sim_level') = 'L1' then 1
    when json_extract_string(payload_json, '$.sim_level') = 'L2' then 2
    else null
  end as sim_level_rank,

  -- optional: SIM steps; fallback = 1 per SIM event (so WL_jit_sim_steps_total is at least “how many SIMs”)
  case when event_type = 'JIT_CONSTRUAL_SIM'
    then coalesce(try_cast(json_extract(payload_json, '$.sim_steps') as bigint), 1)
  else 0 end as sim_steps_or_0

from events_flat
where event_type like 'JIT_CONSTRUAL_%';

-- ----------------------------------------------------------------------
-- 2) Per-cycle timeline: reconstruct active_set_n_t by cumsum adds/removes
-- ----------------------------------------------------------------------

create or replace view v_jit_cycle_timeline as
with e as (
  select
    *,
    coalesce(added_n, 0) as added_n0,
    coalesce(removed_n, 0) as removed_n0
  from v_jit_events
),
seed as (
  select
    *,
    max(seed_n) over (partition by episode_id, jit_cycle_id) as seed_n_cycle
  from e
)
select
  *,
  seed_n_cycle
    + sum(added_n0) over (
        partition by episode_id, jit_cycle_id
        order by observed_time, recorded_time, event_id
        rows between unbounded preceding and current row
      )
    - sum(removed_n0) over (
        partition by episode_id, jit_cycle_id
        order by observed_time, recorded_time, event_id
        rows between unbounded preceding and current row
      ) as active_set_n_t
from seed;

-- ----------------------------------------------------------------------
-- 3) Per-cycle stats
-- ----------------------------------------------------------------------

create or replace view v_jit_cycle_stats as
select
  episode_id,
  jit_cycle_id,

  -- active set
  avg(active_set_n_t) as active_set_mean,
  max(active_set_n_t) as active_set_max,

  -- needs / churn
  sum(coalesce(needs_n, 0)) as need_count_total,
  sum(coalesce(added_n, 0)) as obj_added_total,
  sum(coalesce(removed_n, 0)) as obj_removed_total,

  -- sim
  max(sim_level_rank) as sim_level_rank_max,
  case max(sim_level_rank)
    when 0 then 'L0'
    when 1 then 'L1'
    when 2 then 'L2'
    else null
  end as sim_level_max,
  sum(sim_steps_or_0) as sim_steps_total

from v_jit_cycle_timeline
group by episode_id, jit_cycle_id;

-- ----------------------------------------------------------------------
-- 4) Episode-level covariates: WL_jit_*
-- ----------------------------------------------------------------------

create or replace view v_episode_jit_covariates as
select
  episode_id,
  -- enabled if at least one cycle exists
  (count(*) > 0) as WL_jit_enabled,

  -- cycles
  count(distinct jit_cycle_id) as WL_jit_cycle_count,

  -- active set (episode summary from per-cycle stats)
  avg(active_set_mean) as WL_jit_active_set_mean,
  max(active_set_max) as WL_jit_active_set_max,

  -- needs / churn totals
  sum(need_count_total) as WL_jit_need_count_total,
  sum(obj_added_total) as WL_jit_obj_added_total,
  sum(obj_removed_total) as WL_jit_obj_removed_total,

  -- sim summary
  max(sim_level_rank_max) as _sim_level_rank_max,
  case max(sim_level_rank_max)
    when 0 then 'L0'
    when 1 then 'L1'
    when 2 then 'L2'
    else null
  end as WL_jit_sim_level_max,
  sum(sim_steps_total) as WL_jit_sim_steps_total

from v_jit_cycle_stats
group by episode_id;

-- ----------------------------------------------------------------------
-- 5) SCORE_REPORT enrichment (analysis-time join)
-- ----------------------------------------------------------------------

create or replace view v_score_report_enriched as
select
  sr.*,
  j.WL_jit_enabled,
  j.WL_jit_cycle_count,
  j.WL_jit_active_set_mean,
  j.WL_jit_active_set_max,
  j.WL_jit_need_count_total,
  j.WL_jit_obj_added_total,
  j.WL_jit_obj_removed_total,
  j.WL_jit_sim_level_max,
  j.WL_jit_sim_steps_total
from events_flat as sr
left join v_episode_jit_covariates as j using (episode_id)
where sr.event_type = 'SCORE_REPORT';
