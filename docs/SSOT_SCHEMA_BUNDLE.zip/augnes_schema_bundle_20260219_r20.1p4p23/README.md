# Augnes Schema Bundle (r20.1p4p23, 2026-02-19)

> NOTE: r20.1p4p23은 **버전 정합을 위한 repack**이다. (스키마/계약 내용은 r20.1p4p18과 동일)
이 번들은 프로젝트 폴더 문서(r20.1p4p23)에 맞춘 **검증용 스키마 + 예시** 묶음이다.

## 포함
- `/schema/*.schema.yaml`: JSON Schema (Draft 2020-12) YAML 표현
- `/examples/*.example.json`: 최소 예시(테스트/샘플)

## (NEW) RoTTrace(Render-of-Thought) 예시 추가
- Render-of-Thought(arXiv:2601.14750v2) 계열의 “단일행 이미지/비전 임베딩 기반 trace”를 사건 단위로 남길 때 쓰는 예시를 추가한다.
- 새 예시:
  - `/examples/event_ROT_TRACE_UPDATE.json`



## (NEW) shared prior pipeline 식별자(prior_pipeline_id) 예시
- LPS/G2A/MN priors가 같은 코드 경로(clip→jerk→cooldown)를 탔는지 사후 검증하기 위해, `event_gate_decision.example.json`에 `prior_pipeline_id`(+ 선택 `applied_rules`)를 추가한다.

## (NEW) Memory-ANN-lite (MN) 예시 추가
- “선택을 직접 구동하지 않는 기억 변수” 기반의 Control/View 메트릭을 로그에 남길 때 쓰는 예시를 추가한다.
- 새 예시:
  - `/examples/state_snapshot_with_memory_ann.example.json`
  - `/examples/event_state_snapshot_with_memory_ann.example.json`
  - `/examples/event_gate_decision.example.json` 내 `payload.memory_ann_used` 확장


## 설계 원칙
- **엄격하게 고정해야 하는 것**(3중 시간, UUID, 핵심 필드)은 강제.
- **payload 확장**(PROBE suite 확장 키 등)은 *스키마 확장 없이* 허용하므로 `additionalProperties: true`를 기본으로 한다.
- Evidence/Claim 권위 체계는 Canonical Spec을 따른다.

## (NEW) Compressibility 신호(CompIndex/CompCurve) 확장
- payload 확장 키(예): `comp_index`, `comp_curve`
- 권장 signals 축(예): `Comp_token_lz`, `Comp_policy_lz`, `Comp_et_lz`, `CompCurve_C_glasso`

## (NEW) PROBE suite 확장: AR(추상성) + LAB(Axis Bank) + IFC(형식 수렴)
- payload 확장 키(예): `abstractness_ar`, `axis_bank`, `format_convergence`
- 권장 signals 축(예): `AR_dec_R`, `AR_ccgp_R`, `PS_repr_format`, `LAB_drift_p95`, `FMT_valid_rate`
- 예시 파일:
  - `/examples/event_probe_run_end_abstractness_ar.example.json`
  - `/examples/event_probe_run_end_axis_bank.example.json`
  - `/examples/analysis_signal_ar.example.json`
  - `/examples/analysis_signal_fmt.example.json`

## (NEW) TRM/CGAR Ops-Transplant (PDC / Halting / HSW)
- 스키마는 payload 확장을 허용하므로, 본 번들은 **예시**에서만 키를 추가한다.
- 권장 키(예): `budget.pdc_stage_id`, `budget.pdc_round`, `budget.pdc_stage_tau_cap`, `budget.act_halt_margin`, `budget.halt_reason`, `outcome_metrics.hsw_lambda`, `outcome_metrics.hsw_weight_last`, `outcome_metrics.hsw_rounds`.
- 상세 규칙/의미론은 Canonical Spec §11.1.2 및 Logging Appendix를 따른다.

## (NEW) BG/Gate Learned Prediction Signal(LPS) + ΔQ_hat/ΔQ_over_M (PDC 승격용)
- `STATE_SNAPSHOT.payload.metrics_optional.learned_pred`에 초소형 예측 신호를 저장한다(스키마 확장 없이 optional).
  - `commit_fail_hat`, `verify_gain_hat`
  - (optional) `cost_hat.{tokens,tool_calls,latency_ms}`
  - (optional) `delta_q_hat`, `delta_q_over_m_hat`, `delta_m_hat`
  - (optional) `p_improve`, `p_loop`, `conf`
- (권장) `GATE_DECISION.payload.learned_pred_used`에 Gate가 실제로 쓴 값(clip/EMA 이후) + `lps_weight`, `reason_codes`를 기록한다.
- 주의: 위 값들은 **Control/진단 로그**이며 Evidence/Claim 권위를 만들지 않는다(override 금지).

새 예시:
- `/examples/event_gate_decision.example.json`
- `/examples/state_snapshot_with_learned_pred.example.json`
## (NEW) CSB(Cerebellar Satellite Bank): Sat-L(Δlogits) / Sat-M(Δpolicy_score) 출력 분리 + PROBE 예시
- `STATE_SNAPSHOT.payload.metrics_optional.cerebellar_satellites`에 위성 출력/게인/선택성 요약을 남긴다(스키마는 optional + payload 확장 허용).
- `PROBE_RUN_END`에 `probe_suite_id=csb_satellite_v0` + `satellite_metrics_by_profile`를 남기는 예시를 추가한다.
- 주의: 위 값들은 **Control/진단 로그**이며 Evidence/Claim 권위를 만들지 않는다(τ_stop 입력 금지).

새 예시:
- `/examples/state_snapshot_with_csb.example.json`
- `/examples/event_probe_run_end_csb.example.json`



## 문서 기준
- `SSOT_CANONICAL.md` (v2.2.2+19, r20.1p4p10)
- `SSOT_LOGGING_POLICY.md` (v2.2.2+19, r20.1p4p10)
- `OPS_PLAYBOOK.md` (v2.2.2+19, r20.1p4p10)
- `MODULE_SIDECAR_QP_ZT_SUMMARY.md` (v0.5.19.2p4p9)
- `WIRING_INTEGRATION_MAP.md` (v2.2.2+19, r20.1p4p10)

## (NEW) Behavioral State Layer (BSL)
- `/schema/behavior_state.schema.yaml`: `STATE_SNAPSHOT.payload.state_core.behavior_state`용 최소 스키마.
- `/schema/state_snapshot.schema.yaml`에 `behavior_state` 참조를 추가.
- `/schema/event_log.schema.yaml`에 `BEHAVIOR_STATE_SWITCH` 조건부 required를 추가.
- `/examples/event_behavior_state_switch.example.json`
## (NEW) Option A: Analysis Store Schema
- `/schema/analysis_event_flat.schema.yaml`: Raw Event Log를 분석용으로 평탄화한 행 스키마(파생, 재생성 가능).
- `/schema/analysis_signal.schema.yaml`: 핵심 수치/축을 long-format(timeseries point)로 저장하는 스키마.
- `/examples/analysis_event_flat.example.json`, `/examples/analysis_signal.example.json`

주의: Analysis Store는 Evidence/Claim 권위를 만들지 않는다(뷰/제어용 파생 저장소).


## (NEW) SSM-lite Digital Twin 확장(선택)
- `/schema/digital_twin.schema.yaml`에 `macro_obs_schema_id`, `macro_obs_hash`, `macro_state_method`, `centroid_hash`, `prototypes_topk`, `risk_set_id`, `zoom_in_trigger` 등 **거시 상태 포인터용 필드**가 추가되어 있다.
- 무거운 벡터/centroid/pca 같은 것은 payload에 직접 넣지 말고, hash/ref(포인터)로만 남기는 걸 권장한다.

## (NEW) (옵션) Dataset 3: macro_state_catalog
- 파생 분석 스토어가 `macro_state_version`별 카탈로그를 별도 파일로 고정할 수 있도록, `analysis_event_flat`의 optional extracted columns 및 `DigitalTwin` 확장 키를 지원한다.
- 스키마는 강제하지 않고(`additionalProperties: true`), 문서(Logging Appendix §12.4.3a) 계약을 따른다.


## (NEW) EOP++ Forecast/Calibration 이벤트 계약
- `/schema/event_log.schema.yaml`에 `EXPECTED_OUTCOME_PACKET`, `PREDICT_OBS_COMPARE` 조건부 required를 추가.
- `/examples/event_expected_outcome_packet.example.json`, `/examples/event_predict_obs_compare.example.json`

주의: EOP/compare는 Evidence 권위를 만들지 않는다(뷰/제어용 이벤트).


## (NEW) Artifact Self-Tuning (Self-evolution)
- `/schema/event_log.schema.yaml`에 `ARTIFACT_TUNE_CANDIDATE/EVAL/COMMIT/ROLLBACK` 조건부 required를 추가.
- `/schema/state_snapshot.schema.yaml`에 `metrics_optional.artifact_tuning`(권장)을 추가.
- `/schema/claim_packet.schema.yaml`, `/schema/trace_capsule.schema.yaml` 추가(구조 압축 산출물).
- `/examples/event_artifact_tune_*.example.json` 예시 추가.

주의: Artifact 튜닝 이벤트는 Evidence/Claim 권위를 만들지 않는다(운영/회귀 관리용).


## (NEW) Iterative Deployment: Dataset/Finetune Runs (옵션)
- `/schema/event_log.schema.yaml`에 `DATASET_BUILD_START/END`, `FINETUNE_RUN_START/END` 조건부 required를 추가.
- `/examples/event_dataset_build_*.example.json`, `/examples/event_finetune_run_*.example.json` 예시 추가.

주의: Dataset/튜닝 런 이벤트는 Evidence/Claim 권위를 만들지 않는다(운영/재현성 로그).

## (NEW) AVR: Metacog Value/Cost + Rubric Report (Control/View)
- Metacog 후보(`COMPETENCE_ASSESSMENT.payload.candidates[]`)에 아래 **옵션** 키를 추가로 기록할 수 있다(스키마는 payload 확장을 허용).
  - `remaining_steps_hat`: number|null (남은 단계/시도 수 프록시)
  - `cost_hat`: object|null
    - `tokens`: number|null
    - `tool_calls`: number|null
    - `latency_ms`: number|null
- 후보/산출물(전략/aux-move/trace-capsule 등)에 대한 다축 채점표를 남기기 위해 `RUBRIC_REPORT` 이벤트 계약을 추가했다.
  - required(payload): `rubric_id`, `target_kind`, `target_id`, `scores`
- 새/갱신 예시:
  - `/examples/event_COMPETENCE_ASSESSMENT.json` (형식 정합화 + value/cost 옵션 추가)
  - `/examples/event_STRATEGY_SELECTION.json` (형식 정합화)
  - `/examples/event_METACOG_CYCLE_END.json` (형식 정합화)
  - `/examples/event_RUBRIC_REPORT.json` (신규)
- 주의: 위 값들은 **Control/진단 로그**이며 Evidence/Claim 권위를 만들지 않는다(τ_stop 입력 금지).

- NEW(r16): Metacog(MUSE-lite) 이벤트 3종 추가(`COMPETENCE_ASSESSMENT`, `STRATEGY_SELECTION`, `METACOG_CYCLE_END`)


## r17 추가
- event_log.schema.yaml: metacog 블록 들여쓰기 버그 수정
- ProgRAG/PSGR 이벤트 타입 추가: PROGRAG_STEP_START/END, PROGRAG_SUBQUESTION, PROGRAG_RELATION_RETRIEVAL, PROGRAG_GRAPH_UPDATE
## (NEW) VAR profile: 구조적 변동성 스케줄 (Structure in noise 이식)
- 위치(권장 단일화): `STATE_SNAPSHOT.payload.metrics_optional.var`
- 필드:
  - `var_profile`: `"quench"|"recurrent"|"auto"`
  - `sa_rank_hat`: number in [0,1]
  - `var_hat`: number in [0,1] (proxy)
  - `ri_selfgraph`: number in [0,1] (Self-Graph reciprocity proxy)
- 권장 파생 signals(예): `VAR_decode_entropy_mean_w`, `VAR_decode_entropy_mad_w`, `VAR_profile_flip_rate`, `RI_selfgraph_mean_w`

## (NEW) koopman_jepa_v0
- SSM-lite(digital twin)의 macro_state를 무감독 레짐 분해로 만들기 위한 representation training method.
- FINETUNE_RUN_START/END 이벤트에서 method="koopman_jepa_v0"를 사용해 학습 런을 기록할 수 있다.
- DigitalTwin 확장 필드: digital_twin.koopman.*
## (NEW) JIT Construal Loop — Working World Model (Just-in-Time)

이 번들은 **작업용 미니 세계모델(=construal / active set)**을 가성비로 굴리기 위한 최소 계약을 추가한다.
- 오브젝트/need는 **증거(evidence)가 아니라 작업 단위**다. 근거는 `evidence_ptrs`로만 연결한다.

### 스키마
- `schema/jit_object.schema.yaml` — 작업용 오브젝트 단위(JIT Object)
- `schema/jit_need.schema.yaml` — lookahead 기반 retrieval 트리거(Need)
- `schema/jit_construal.schema.yaml` — construal(활성 작업세트) 스냅샷

### 이벤트 계약(event_log.schema.yaml)
- `JIT_CONSTRUAL_INIT`
- `JIT_CONSTRUAL_SIM`
- `JIT_CONSTRUAL_LOOKAHEAD`
- `JIT_CONSTRUAL_ENCODE`
- `JIT_CONSTRUAL_PRUNE`
- `JIT_CONSTRUAL_OUTCOME`

### 예시
- `examples/event_JIT_CONSTRUAL_*.json`
- `examples/jit_object.example.json`
- `examples/jit_need.example.json`
- `examples/jit_construal.example.json`

## Compatibility notes
- `MODE_SWITCH.payload.scope` / `BEHAVIOR_STATE_SWITCH.payload.scope`는 선택(옵션) 필드다. 둘을 동시에 운용할 때 분석 축 혼선을 막기 위해 각각 `control_mode` / `behavior_state`로 기록하는 것을 권장한다.
- `STATE_SNAPSHOT.metrics_optional.var`에서 `ri_selfgraph`가 정식 키이며, 레거시 별칭 `RI_selfgraph`를 동일 의미로 허용한다. (분석/ETL에서 COALESCE 표준화 권장)

- (r20.1p4p16) metacog 예시 확장: `wm_meta`(Meta-WM gate), `wm_dependency_hat`, `wm_meta_used` (optional; 계약 변경 없음)


- (업데이트) 본 번들의 최신 문서 스냅샷 타깃: r20.1p4p16 (2026-02-11)
